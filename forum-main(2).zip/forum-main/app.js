const Store = {
    data: {
        user: { name: 'João & Ana', avatar: '🍬' },
        theme: 'dark', route: 'home', activeCatId: null, forumSearch: '',
        activities: [],
        categories: [{ id: 1, title: 'Receitas', emoji: '🍰', topics: [] }],
        gardenZones: [{ id: 1, name: 'Estufa', emoji: '🌿', plants: [] }]
    },
    init() {
        const saved = localStorage.getItem('joaninha_pro_v5');
        if (saved) this.data = JSON.parse(saved);
        this.applyTheme();
        Router.render();
        this.regSW();
    },
    save(render = true) {
        localStorage.setItem('joaninha_pro_v5', JSON.stringify(this.data));
        if (render) Router.render();
    },
    applyTheme() { document.documentElement.className = this.data.theme; },
    log(msg) {
        this.data.activities.unshift({ text: msg, time: new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'}) });
        if(this.data.activities.length > 5) this.data.activities.pop();
    },
    regSW() { if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(()=>{}); }
};

const Router = {
    navigate(route) {
        Store.data.route = route;
        Store.data.activeCatId = null;
        Store.save();
    },
    render() {
        const vp = document.getElementById('app-viewport');
        const r = Store.data.route;
        
        document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
        document.getElementById(`nav-${r}`).classList.add('active');

        let html = '';
        if(r === 'home') html = Views.home();
        if(r === 'forum') html = Views.forum();
        if(r === 'garden') html = Views.garden();
        if(r === 'config') html = Views.config();
        
        vp.innerHTML = `<div class="view-transition">${html}</div>`;
        lucide.createIcons();
    }
};

const Views = {
    home: () => `
        <div class="mb-8">
            <h1 class="text-4xl font-black italic text-[#5865F2] tracking-tighter">JOANINHA SABORES</h1>
            <p class="text-xs font-bold opacity-50 uppercase mt-1">Bem-vindos, ${Store.data.user.name}</p>
        </div>
        <div class="grid gap-4 mb-8">
            <div class="card p-6 border-l-4 border-[#5865F2]">
                <p class="text-[10px] font-black opacity-40 uppercase">Notas</p>
                <p class="text-2xl font-bold">${Store.data.categories.length} Categorias</p>
            </div>
            <div class="card p-6 border-l-4 border-[#23A559]">
                <p class="text-[10px] font-black opacity-40 uppercase">Horta</p>
                <p class="text-2xl font-bold">${Store.data.gardenZones.length} Zonas Ativas</p>
            </div>
        </div>
        <div class="card p-6">
            <h3 class="text-[10px] font-black opacity-30 uppercase mb-4 tracking-widest">Últimos Registos</h3>
            <div class="space-y-3">
                ${Store.data.activities.map(a => `<div class="flex justify-between text-sm border-b border-white/5 pb-2"><span>${a.text}</span><span class="opacity-30 text-[10px]">${a.time}</span></div>`).join('') || '<p class="opacity-20 italic">Sem atividade.</p>'}
            </div>
        </div>`,

    forum: () => {
        if (Store.data.activeCatId) {
            const cat = Store.data.categories.find(c => c.id === Store.data.activeCatId);
            return `
                <button onclick="Router.navigate('forum')" class="mb-4 text-[#5865F2] font-bold flex items-center text-xs uppercase"><i data-lucide="chevron-left" class="w-4 h-4 mr-1"></i> Voltar</button>
                <div class="bg-[#5865F2] p-4 rounded-t-app font-black text-white italic uppercase">${cat.title}</div>
                <div class="bg-discord-darker p-4 border-x border-white/5">
                    <input type="text" placeholder="Pesquisar..." oninput="Actions.search(this.value, ${cat.id})" class="text-sm">
                </div>
                <div id="topic-list" class="bg-discord-darker rounded-b-app border border-white/5 divide-y divide-white/5">
                    ${Views.renderTopics(cat.id)}
                </div>
                <button onclick="Actions.modal('topic', ${cat.id})" class="fixed bottom-24 right-6 bg-[#5865F2] p-5 rounded-full text-white shadow-2xl"><i data-lucide="plus"></i></button>`;
        }
        return `
            <h1 class="text-2xl font-black mb-6 italic uppercase">Apontamentos</h1>
            <div class="grid gap-3">
                ${Store.data.categories.map(c => `
                    <div onclick="Actions.openCat(${c.id})" class="card p-5 flex justify-between items-center cursor-pointer">
                        <div class="flex items-center space-x-4">
                            <span class="text-3xl">${c.emoji}</span>
                            <div><h3 class="font-bold text-lg leading-tight">${c.title}</h3><p class="text-[10px] opacity-40 font-black">${c.topics.length} Tópicos</p></div>
                        </div>
                        <button onclick="event.stopPropagation(); Actions.delCat(${c.id})" class="text-[#ED4245] opacity-20 hover:opacity-100"><i data-lucide="trash-2" class="w-5 h-5"></i></button>
                    </div>`).join('')}
                <button onclick="Actions.modal('cat')" class="w-full mt-4 border-2 border-dashed border-white/10 p-4 rounded-app text-gray-500 font-bold text-xs uppercase">+ Nova Categoria</button>
            </div>`;
    },

    renderTopics: (cid) => {
        const cat = Store.data.categories.find(c => c.id === cid);
        const filtered = cat.topics.filter(t => t.title.toLowerCase().includes(Store.data.forumSearch.toLowerCase()));
        return filtered.map(t => `
            <div class="p-5">
                <div class="flex justify-between items-start mb-2">
                    <h4 class="font-bold text-[#5865F2] text-lg flex-1">${t.title}</h4>
                    <div class="flex space-x-3">
                        <button onclick="Actions.modal('topic', ${cid}, ${t.id})" class="opacity-30"><i data-lucide="edit-3" class="w-4 h-4"></i></button>
                        <button onclick="Actions.delTopic(${cid}, ${t.id})" class="text-[#ED4245] opacity-30"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
                    </div>
                </div>
                <div class="text-sm opacity-90 whitespace-pre-wrap">${t.content}</div>
                <div class="text-[9px] opacity-30 mt-4 uppercase font-bold tracking-widest">${t.date}</div>
            </div>`).join('') || '<p class="p-10 text-center opacity-20">Nada a mostrar.</p>';
    },

    garden: () => `
        <h1 class="text-2xl font-black mb-6 italic uppercase">Minha Horta</h1>
        <div class="space-y-6">
            ${Store.data.gardenZones.map(z => `
                <div class="card overflow-hidden">
                    <div class="bg-black/20 p-4 flex justify-between items-center border-b border-white/5">
                        <h3 class="font-black text-[#23A559] uppercase text-sm">${z.emoji} ${z.name}</h3>
                        <div class="flex items-center space-x-2">
                            <button onclick="Actions.modal('plant', ${z.id})" class="bg-[#23A559] text-white px-3 py-1 rounded-lg text-[10px] font-black">ADD</button>
                            <button onclick="Actions.delZone(${z.id})" class="text-[#ED4245] opacity-20"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
                        </div>
                    </div>
                    <div class="p-4 space-y-3">
                        ${z.plants.map(p => `
                            <div class="bg-black/10 p-4 rounded-xl relative border border-white/5">
                                <button onclick="Actions.delPlant(${z.id}, ${p.id})" class="absolute top-3 right-3 text-[#ED4245] opacity-30"><i data-lucide="x" class="w-4 h-4"></i></button>
                                <h4 class="font-bold mb-1">${p.name}</h4>
                                <div class="flex gap-4 text-[9px] font-black opacity-40 uppercase">
                                    <span>📅 ${p.date}</span><span>🌱 ${p.harvest}d</span><span>🌡️ ${p.temp}°c</span>
                                </div>
                                ${p.notes ? `<p class="mt-2 text-[11px] opacity-50 italic">"${p.notes}"</p>` : ''}
                            </div>`).join('')}
                    </div>
                </div>`).join('')}
            <button onclick="Actions.modal('zone')" class="w-full border-2 border-dashed border-white/10 p-4 rounded-app text-gray-500 font-bold text-xs uppercase">+ Nova Zona de Cultivo</button>
        </div>`,

    config: () => `
        <h1 class="text-2xl font-black mb-6 italic uppercase">Definições</h1>
        <div class="space-y-4">
            <button onclick="Actions.toggleTheme()" class="w-full card p-5 flex justify-between items-center text-xs font-bold uppercase tracking-widest">
                <span>Tema Visual</span><span class="text-[#5865F2]">${Store.data.theme}</span>
            </button>
            <div class="card p-6 space-y-4">
                <button onclick="Actions.export()" class="w-full bg-white/5 p-4 rounded-xl font-bold text-[10px] uppercase border border-white/5 flex items-center justify-center"><i data-lucide="download" class="mr-2 w-4 h-4"></i> Exportar Backup</button>
                <label class="w-full bg-white/5 p-4 rounded-xl font-bold text-[10px] uppercase border border-white/5 flex items-center justify-center cursor-pointer">
                    <i data-lucide="upload" class="mr-2 w-4 h-4"></i> Importar Backup
                    <input type="file" class="hidden" onchange="Actions.import(event)">
                </label>
                <button onclick="Actions.reset()" class="w-full text-[#ED4245] font-bold text-[10px] uppercase opacity-40 pt-4">Reset Total</button>
            </div>
        </div>`
};

const Actions = {
    search(v, cid) {
        Store.data.forumSearch = v;
        const list = document.getElementById('topic-list');
        if(list) { list.innerHTML = Views.renderTopics(cid); lucide.createIcons(); }
        Store.save(false);
    },
    toggleTheme() { Store.data.theme = Store.data.theme === 'dark' ? 'light' : 'dark'; Store.applyTheme(); Store.save(); },
    openCat(id) { Store.data.activeCatId = id; Store.save(); },
    modal(type, pid, tid = null) {
        const overlay = document.getElementById('modal-overlay');
        const body = document.getElementById('modal-body');
        let c = '';
        const btn = "w-full bg-[#5865F2] p-4 rounded-xl font-black mt-6 uppercase text-white tracking-widest shadow-lg";

        if(type==='topic') {
            const topic = tid ? Store.data.categories.find(x=>x.id===pid).topics.find(x=>x.id===tid) : {title:'', content:''};
            c = `<h3 class="font-black text-[#5865F2] mb-4 italic text-sm uppercase">${tid ? 'Editar' : 'Novo'} Apontamento</h3>
                 <input id="m-t" placeholder="Título..." value="${topic.title}">
                 <textarea id="m-c" placeholder="Escreve aqui..." class="mt-3 h-48">${topic.content}</textarea>
                 <button onclick="Actions.saveTopic(${pid}, ${tid})" class="${btn}">${tid ? 'Guardar' : 'Publicar'}</button>`;
        }
        else if(type==='cat') c = `<h3 class="font-black mb-4 italic uppercase text-sm">Nova Categoria</h3><input id="m-e" placeholder="Emoji" class="mb-2"><input id="m-t" placeholder="Nome..."><button onclick="Actions.saveCat()" class="${btn}">Criar</button>`;
        else if(type==='zone') c = `<h3 class="font-black text-[#23A559] mb-4 italic uppercase text-sm">Nova Zona</h3><input id="m-e" placeholder="Emoji" class="mb-2"><input id="m-n" placeholder="Nome da Zona..."><button onclick="Actions.saveZone()" class="${btn.replace('5865F2', '23A559')}">Adicionar</button>`;
        else if(type==='plant') c = `<h3 class="font-black text-[#23A559] mb-4 italic uppercase text-sm">Nova Planta</h3><input id="m-n" placeholder="Nome"><div class="grid grid-cols-2 gap-2 mt-3"><input id="m-d" type="date"><input id="m-h" type="number" placeholder="Dias"></div><input id="m-tp" type="number" placeholder="Temp. Ideal" class="mt-3"><textarea id="m-nt" placeholder="Notas..." class="mt-3 h-24"></textarea><button onclick="Actions.savePlant(${pid})" class="${btn.replace('5865F2', '23A559')}">Guardar</button>`;

        body.innerHTML = c;
        overlay.classList.replace('hidden', 'flex');
    },
    close() { document.getElementById('modal-overlay').classList.replace('flex', 'hidden'); },
    saveTopic(cid, tid) {
        const t = document.getElementById('m-t').value;
        const c = document.getElementById('m-c').value;
        if(t) {
            const cat = Store.data.categories.find(x=>x.id===cid);
            if(tid) { 
                const top = cat.topics.find(x=>x.id===tid); top.title = t; top.content = c; 
            } else { 
                cat.topics.unshift({ id: Date.now(), title: t, content: c, date: new Date().toLocaleDateString() }); 
            }
            Store.log(tid ? "Nota editada" : "Nota criada"); this.close(); Store.save();
        }
    },
    saveCat() {
        const t = document.getElementById('m-t').value;
        if(t) { Store.data.categories.push({ id: Date.now(), title: t, emoji: document.getElementById('m-e').value || '📁', topics: [] }); this.close(); Store.save(); }
    },
    saveZone() {
        const n = document.getElementById('m-n').value;
        if(n) { Store.data.gardenZones.push({ id: Date.now(), name: n, emoji: document.getElementById('m-e').value || '🪴', plants: [] }); this.close(); Store.save(); }
    },
    savePlant(zid) {
        const n = document.getElementById('m-n').value;
        if(n) { Store.data.gardenZones.find(x=>x.id===zid).plants.unshift({ id: Date.now(), name: n, date: document.getElementById('m-d').value || '--', harvest: document.getElementById('m-h').value || '0', temp: document.getElementById('m-tp').value || '0', notes: document.getElementById('m-nt').value }); this.close(); Store.save(); }
    },
    delCat(id) { if(confirm('Apagar categoria?')) { Store.data.categories = Store.data.categories.filter(c=>c.id!==id); Store.save(); } },
    delTopic(cid, tid) { if(confirm('Apagar nota?')) { Store.data.categories.find(x=>x.id===cid).topics = Store.data.categories.find(x=>x.id===cid).topics.filter(t=>t.id!==tid); Store.save(); } },
    delZone(id) { if(confirm('Apagar zona?')) { Store.data.gardenZones = Store.data.gardenZones.filter(z=>z.id!==id); Store.save(); } },
    delPlant(zid, pid) { if(confirm('Remover planta?')) { const z = Store.data.gardenZones.find(x=>x.id===zid); z.plants = z.plants.filter(p=>p.id!==pid); Store.save(); } },
    export() { const blob = new Blob([JSON.stringify(Store.data)], {type:'application/json'}); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'joaninha_backup.json'; a.click(); },
    import(e) { 
        const r = new FileReader(); 
        r.onload = (x) => { try { Store.data = JSON.parse(x.target.result); Store.save(); alert('Sucesso!'); } catch(i){ alert('Erro!'); } }; 
        r.readAsText(e.target.files[0]); 
    },
    reset() { if(confirm('Limpar tudo?')) { localStorage.clear(); location.reload(); } }
};

window.onload = () => Store.init();
window.onclick = (e) => { if(e.target.id === 'modal-overlay') Actions.close(); };