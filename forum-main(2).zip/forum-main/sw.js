const CACHE_NAME = 'joaninha-cache-v1';
// Lista de ficheiros a guardar para sempre
const urlsToCache = [
  './',
  './index.html',
  './style.css',
  './app.js',
  './manifest.json',
  './icon.png',
  'https://cdn.tailwindcss.com',
  'https://unpkg.com/lucide@latest',
  'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap'
];

// Instala o Service Worker e guarda os ficheiros no telemóvel
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      console.log('Cofre aberto: Guardando ficheiros para modo offline');
      return cache.addAll(urlsToCache);
    })
  );
});

// Quando não houver net, ele vai buscar ao cofre em vez de ir à nuvem
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request).then(response => {
      return response || fetch(event.request);
    })
  );
});